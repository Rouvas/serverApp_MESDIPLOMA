export class SymptomInstanceDto {
  name: string;
  presence: boolean;
  severity?: number;
  durationDays?: number;
}
