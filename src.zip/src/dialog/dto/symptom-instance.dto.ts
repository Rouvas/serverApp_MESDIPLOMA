export class SymptomInstanceDto {
  key: string;
  presence: boolean;
  severity?: number;
  durationDays?: number;
}
