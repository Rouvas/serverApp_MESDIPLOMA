import { Module } from '@nestjs/common';
import { DialogService } from './dialog.service';
import { DialogController } from './dialog.controller';
import { BayesianModule } from '../bayesian/bayesian.module';
import { ScenariosModule } from '../scenarios/scenarios.module';
import { SymptomsModule } from '../symptoms/symptoms.module';

@Module({
  imports: [SymptomsModule, ScenariosModule, BayesianModule],
  providers: [DialogService],
  controllers: [DialogController],
})
export class DialogModule {}
