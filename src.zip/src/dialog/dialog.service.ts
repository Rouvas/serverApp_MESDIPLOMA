import { Injectable, NotFoundException } from '@nestjs/common';
import { NlpService } from '../nlp/nlp.service';
import { ScenariosService } from '../scenarios/scenarios.service';
import { BayesianService, Ranking } from '../bayesian/bayesian.service';
import { DialogAnswerResponse } from './interfaces/dialog-response.interface';
import { randomUUID } from 'crypto';
import { SymptomInstanceDto } from './dto/symptom-instance.dto';

@Injectable()
export class DialogService {
  // Хранилище сессий: dialogId → { scenarioId, facts: string[] }
  private sessions = new Map<string, { scenarioId: string; facts: string[] }>();

  constructor(
    private readonly symptomsSvc: NlpService,
    private readonly scenariosSvc: ScenariosService,
    private readonly bayesianSvc: BayesianService,
  ) {}

  /**
   * 1) извлекаем симптомы из текста,
   * 2) ищем сценарий,
   * 3) инициализируем сессию,
   * 4) считаем начальный рейтинг
   */
  async start(text: string) {
    const symptoms = this.symptomsSvc.extract(text); // string[]

    // Преобразуем в SymptomInstanceDto[]
    const instances: SymptomInstanceDto[] = symptoms.map((name) => ({
      name,
      presence: true,
      // severity и durationDays пока undefined
    }));

    const scenarios = await this.scenariosSvc.findRelevant(symptoms);
    if (scenarios.length === 0) {
      return { message: 'Подходящие сценарии не найдены', symptoms };
    }
    const scenario = scenarios[0];

    // Ранжируем диагнозы по Байесу
    const ranking: Ranking[] =
      await this.bayesianSvc.calculateScores(instances);

    // Создаём новую сессию
    const dialogId = randomUUID();
    this.sessions.set(dialogId, {
      scenarioId: scenario._id.toString(),
      facts: [...symptoms],
    });

    const nextQuestion = scenario.questions[0] || null;

    return { dialogId, symptoms, scenario, nextQuestion, ranking };
  }

  /**
   * 1) подтверждаем факт (если yes — добавляем в facts),
   * 2) находим следующий вопрос,
   * 3) пересчитываем рейтинг
   */
  async next(
    dialogId: string,
    key: string,
    answer: string,
  ): Promise<DialogAnswerResponse> {
    const session = this.sessions.get(dialogId);
    if (!session) throw new NotFoundException(`Session ${dialogId} not found`);

    if (answer.trim().toLowerCase() === 'yes') {
      if (!session.facts.includes(key)) session.facts.push(key);
    }

    const scenario = await this.scenariosSvc.findById(session.scenarioId);
    if (!scenario)
      throw new NotFoundException(`Scenario ${session.scenarioId} not found`);

    // Выбираем следующий вопрос по сценарию
    const idx = scenario.questions.findIndex((q) => q.key === key);
    const nextQuestion =
      idx + 1 < scenario.questions.length ? scenario.questions[idx + 1] : null;
    const finished = nextQuestion === null;

    // Преобразуем накопленные факты в DTO
    const instances: SymptomInstanceDto[] = session.facts.map((name) => ({
      name,
      presence: true,
    }));

    // Пересчитываем рейтинг
    const ranking: Ranking[] =
      await this.bayesianSvc.calculateScores(instances);

    return {
      dialogId,
      facts: session.facts,
      scenario,
      nextQuestion,
      ranking,
      finished,
    };
  }
}
