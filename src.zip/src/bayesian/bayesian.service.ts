import { Injectable } from '@nestjs/common';
import { Disease } from '../diseases/disease.schema';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { SymptomInstanceDto } from '../dialog/dto/symptom-instance.dto';

export interface Ranking {
  disease: string;
  score: number;
}

@Injectable()
export class BayesianService {
  constructor(
    @InjectModel(Disease.name)
    private readonly diseaseModel: Model<Disease>,
  ) {}

  /**
   * Ранжирует заболевания по апостериорной вероятности
   */
  async calculateScores(instances: SymptomInstanceDto[]): Promise<Ranking[]> {
    const diseases = await this.diseaseModel.find().lean().exec();

    // строим Map<симптом, DTO>
    const instMap = new Map(instances.map((i) => [i.name, i]));

    const raw = diseases.map((d) => {
      let score = d.prior;
      for (const rule of d.symptomRules) {
        const inst = instMap.get(rule.name);
        const p = rule.probability;
        if (inst?.presence) {
          const okSeverity =
            rule.minSeverity == null ||
            (inst.severity ?? 0) >= rule.minSeverity;
          const okDuration =
            rule.minDurationDays == null ||
            (inst.durationDays ?? 0) >= rule.minDurationDays;
          score *= okSeverity && okDuration ? p : p * 0.5;
        } else {
          score *= 1 - p;
        }
      }
      return { name: d.name, score };
    });

    // нормализуем, если нужно, или сразу возвращаем score
    // (нормализация по вашему усмотрению)
    const total = raw.reduce((sum, x) => sum + x.score, 0) || 1;
    const normalized = raw.map((x) => ({
      name: x.name,
      score: x.score / total,
    }));

    // и возвращаем уже в форме Ranking
    return normalized
      .map((x) => ({ disease: x.name, score: x.score }))
      .sort((a, b) => b.score - a.score);
  }
}
