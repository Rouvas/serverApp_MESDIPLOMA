import { Module } from '@nestjs/common';
import { DiagnosisController } from './diagnosis.controller';
import { DiagnosisService } from './diagnosis.service';
import { SymptomsModule } from '../symptoms/symptoms.module';
import { ScenariosModule } from '../scenarios/scenarios.module';
import { BayesianModule } from '../bayesian/bayesian.module';

@Module({
  imports: [
    SymptomsModule, // модуль для извлечения симптомов из текста
    ScenariosModule, // модуль логических сценариев
    BayesianModule, // модуль байесовского ранжирования
  ],
  controllers: [DiagnosisController],
  providers: [DiagnosisService],
})
export class DiagnosisModule {}
