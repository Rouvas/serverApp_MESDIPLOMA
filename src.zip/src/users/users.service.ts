// src/users/users.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User, UserDocument } from './user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

  async create(dto: CreateUserDto): Promise<Omit<User, 'password'>> {
    const hash = await bcrypt.hash(dto.password, 10);
    const created = await this.userModel.create({ ...dto, password: hash });
    const { password, ...u } = created.toObject();
    return u;
  }

  async findOneByUsername(username: string): Promise<UserDocument> {
    return await this.userModel.findOne({ username }).exec();
  }

  async findById(id: string): Promise<UserDocument> {
    const u = await this.userModel.findById(id).exec();
    if (!u) throw new NotFoundException(`User ${id} not found`);
    return u;
  }
}
