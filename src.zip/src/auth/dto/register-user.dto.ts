import { IsString, MinLength, IsEnum } from 'class-validator';
import { Role } from '../../users/user.schema';

export class RegisterUserDto {
  @IsString() readonly username: string;
  @IsString() @MinLength(6) readonly password: string;
  @IsEnum(Role) readonly role: Role;
}
