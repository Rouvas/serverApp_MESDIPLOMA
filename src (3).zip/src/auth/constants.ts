export const jwtConstants = {
  secret: 'SUPER_SECRET_KEY_123',
  expiresIn: '1h',
};
