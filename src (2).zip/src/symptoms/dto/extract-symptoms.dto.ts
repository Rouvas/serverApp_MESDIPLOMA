import { IsString, IsNotEmpty } from 'class-validator';

/**
 * DTO для первичного ввода от пользователя (raw текст)
 */
export class ExtractSymptomsDto {
  @IsString()
  @IsNotEmpty()
  text: string;
}
