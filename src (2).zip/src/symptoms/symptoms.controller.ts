import { Controller, Post, Body } from '@nestjs/common';
import { SymptomsService } from './symptoms.service';
import { ExtractSymptomsDto } from './dto/extract-symptoms.dto';

@Controller('symptoms')
export class SymptomsController {
  constructor(private readonly svc: SymptomsService) {}

  /**
   * POST /symptoms
   * принимает "raw text" и возвращает список найденных симптомов
   */
  @Post()
  extract(@Body() dto: ExtractSymptomsDto) {
    const list = this.svc.extract(dto.text);
    return { symptoms: list };
  }
}
