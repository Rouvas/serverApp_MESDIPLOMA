import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DiseasesModule } from './diseases/diseases.module';
import { MongooseModule } from '@nestjs/mongoose';
import { SymptomsModule } from './symptoms/symptoms.module';
import { ScenariosModule } from './scenarios/scenarios.module';
import { BayesianModule } from './bayesian/bayesian.module';
import { DialogModule } from './dialog/dialog.module';
import { AuthModule } from './auth/auth.module';
import { ConfigModule } from '@nestjs/config';
import { UsersModule } from './users/users.module';
import { DiagnosisModule } from './diagnosis/diagnosis.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    MongooseModule.forRoot('mongodb://localhost/mesdiploma'),
    DiseasesModule,
    SymptomsModule,
    ScenariosModule,
    BayesianModule,
    DialogModule,
    AuthModule,
    UsersModule,
    DiagnosisModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
