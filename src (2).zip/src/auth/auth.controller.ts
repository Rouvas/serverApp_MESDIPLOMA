import { Controller, Post, Body } from '@nestjs/common';
import { AuthService } from './auth.service';
import { RegisterUserDto } from './dto/register-user.dto';
import { LoginDto } from './dto/login.dto';

@Controller('auth')
export class AuthController {
  constructor(private authSvc: AuthService) {}

  // @Post('register')
  // register(@Body() dto: RegisterUserDto) {
  //   return this.authSvc.usersSvc.create(dto);
  // }

  @Post('login')
  login(@Body() dto: LoginDto) {
    return this.authSvc.login(dto);
  }
}
