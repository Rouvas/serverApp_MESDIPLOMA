import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Disease } from '../diseases/schemas/disease.schema';
import { SymptomInstanceDto } from '../dialog/dto/symptom-instance.dto';

export interface Ranking {
  disease: string;
  score: number;
}

@Injectable()
export class BayesianService {
  constructor(
    @InjectModel(Disease.name)
    private readonly diseaseModel: Model<Disease>,
  ) {}

  /**
   * Ранжирует заболевания по апостериорной вероятности,
   * учитывая штраф за нехарактерные симптомы и клинические предикаты
   */
  async calculateScores(instances: SymptomInstanceDto[]): Promise<Ranking[]> {
    const diseases = await this.diseaseModel.find().lean().exec();

    const instMap = new Map(instances.map((i) => [i.key, i]));
    const allSymptomKeys = new Set(instances.map((i) => i.key));

    // Штраф для каждого неподтвержденного утверждения о наличии симптома
    const MISSING_PRESENCE_PENALTY = 0.01;

    const rawScores = diseases.map((d) => {
      let logScore = Math.log(d.prior);

      // обработка фактов о симптомах
      for (const key of allSymptomKeys) {
        const inst = instMap.get(key);
        const rule = d.symptomRules.find((r) => r.name === key);

        if (inst.presence) {
          if (rule) {
            // Проверяем предикаты, если они заданы
            const okSeverity =
              rule.minSeverity == null ||
              (inst.severity ?? 0) >= rule.minSeverity;
            const okDuration =
              rule.minDurationDays == null ||
              (inst.durationDays ?? 0) >= rule.minDurationDays;
            // Если оба ограничения соблюдены — полная вероятность, иначе половинная
            const p =
              okSeverity && okDuration
                ? rule.probability
                : rule.probability * 0.5;
            logScore += Math.log(p);
          } else {
            // Для нехарактерного симптома — штраф
            logScore += Math.log(MISSING_PRESENCE_PENALTY);
          }
        } else {
          // Явное отсутствие симптома — влияет только если есть правило
          if (rule) {
            logScore += Math.log(1 - rule.probability);
          }
        }
      }

      return { disease: d.name, logScore };
    });

    // нормализация через softmax для числовой стабильности
    const maxLog = Math.max(...rawScores.map((r) => r.logScore));
    const exps = rawScores.map((r) => ({
      disease: r.disease,
      exp: Math.exp(r.logScore - maxLog),
    }));

    const sumExp = exps.reduce((sum, x) => sum + x.exp, 0);
    const rankings: Ranking[] = exps.map((x) => ({
      disease: x.disease,
      score: x.exp / sumExp,
    }));

    return rankings.sort((a, b) => b.score - a.score);
  }
}
