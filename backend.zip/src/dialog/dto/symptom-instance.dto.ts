export class SymptomInstanceDto {
  key: string;
  presence: boolean;
}
